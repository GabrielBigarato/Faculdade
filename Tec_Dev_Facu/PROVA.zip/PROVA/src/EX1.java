// PROVA REGIMENTAL
// ALUNOS:
// GABRIEL BIGARATO          RGM 32831048
// MARIA EDUARDA GOMES LOPES RGM 33292345

import java.util.Scanner;

public class EX1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("digite o tamanho do vetor tem que ser PAR: ");

        int tamanho = scanner.nextInt();
        
        if (tamanho % 2 != 0) {
            System.out.println("o tamanho do vetor tem que ser parrrrrr tchau profi");
            
        }
        int[] vetorr = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            System.out.print("digite o numero pro lugar " + i + ": ");
            vetorr[i] = scanner.nextInt();
        }
        organizaVetor(vetorr);
        System.out.println("\nvetor organizadinho:");
        for (int valorzinho : vetorr) {
            System.out.print(valorzinho + " ");
        }
        scanner.close();
    }
    private static void organizaVetor(int[] vetorr) {
        int ttamanho = vetorr.length;
        for (int i = 0; i < ttamanho; i++) {
            for (int j = i + 1; j < ttamanho; j++) {
                if (vetorr[i] % 2 != 0 && vetorr[j] % 2 == 0) {
                    int temp = vetorr[i];
                    vetorr[i] = vetorr[j];
                    vetorr[j] = temp;
                }
            }
        }
    }
}

