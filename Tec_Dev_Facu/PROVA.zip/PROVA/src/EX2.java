// PROVA REGIMENTAL
// ALUNOS:
// GABRIEL BIGARATO          RGM 32831048
// MARIA EDUARDA GOMES LOPES RGM 33292345
import java.util.Scanner;
public class EX2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("fala ai o tamanho do vitor: ");
        int tamanho = scanner.nextInt();
        int[] vetor = new int[tamanho];
        for (int i = 0; i < tamanho; i++) {
            System.out.print("escreve o valor para o lugar " + i + ": ");
            vetor[i] = scanner.nextInt();
        }
        ordenaVetor(vetor);
        System.out.println("\nvetor arrumadinho:");
        for (int valor : vetor) {
            System.out.print(valor + " ");
        }
        scanner.close();
    }
    private static void ordenaVetor(int[] vetor) {
        int tamanho = vetor.length;
        if (tamanho % 2 != 0) {
            System.out.println("vetor e impar a ordenacao nao sera feita.");
            return;
        }
        int metadeTamanho = tamanho / 2;
        for (int i = 0; i < metadeTamanho; i++) {
            if (vetor[i] > vetor[tamanho - 1 - i]) {
                int temp = vetor[i];
                vetor[i] = vetor[tamanho - 1 - i];
                vetor[tamanho - 1 - i] = temp;
            }
        }
    }
}
