// PROVA REGIMENTAL
// ALUNOS:
// GABRIEL BIGARATO          RGM 32831048
// MARIA EDUARDA GOMES LOPES RGM 33292345
import java.util.Scanner;

public class EX3 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] vetor = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        System.out.print("digite o numero que voce quer buscar: ");
        int numeroBusca = scanner.nextInt();

        int procedimentos = buscabinaria(vetor, numeroBusca);

        if (procedimentos != -1) {
            System.out.println("o numero " + numeroBusca + " foi achado");
            System.out.println("numero de procedimentos necessarios: " + procedimentos);
        } else {
            System.out.println("o numero " + numeroBusca + " não foi encontrado no vetor.");
        }

        scanner.close();
    }

    private static int buscabinaria(int[] vetor, int alvo) {
        int inicio = 0;
        int fim = vetor.length - 1;
        int procedimentos = 0;

        while (inicio <= fim) {
            int meio = (inicio + fim) / 2;
            procedimentos++;

            if (vetor[meio] == alvo) {
                return procedimentos; 
            } else if (vetor[meio] < alvo) {
                inicio = meio + 1; 
            } else {
                fim = meio - 1;
            }
        }
        return -1;
    }
}
